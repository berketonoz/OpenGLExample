
#pragma once
#include "Mesh.h"
#include "Model.h"
#include "GameObject.h"
//#include "AABB.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


class Object : public GameObject{
    
public:
    Object(const Model &m, glm::vec3 s, bool w = true):GameObject(m,s), size(s), is_wall(w){}
    
    glm::vec3 GetPosition() const{return this->position;}
    
    void Collect(vector<Object> &objects){}

    bool CheckCollision(const std::vector<float> mins, std::vector<float> maxs, std::vector<float> minsObj, std::vector<float> maxsObj, glm::vec3 pos, glm::vec3 obj_pos, glm::vec3 size) const {return true;}
    
    void Draw(Shader shader, glm::vec3 position) {
        if(this->visible == true){
            this->position = position;
            translation = glm::mat4(1.0f);
            translation = glm::translate( translation, position); // Translate to position
            translation = glm::scale(translation, size);    //Size of the object
            glUniformMatrix4fv( glGetUniformLocation( shader.Program, "model" ), 1, GL_FALSE,glm::value_ptr(translation)  );
            this->GetModel().Draw(shader);
        }
    }
    
   
    glm::mat4 GetTranslation() const{return this->translation;}
    void SetVisible(bool v) {this->visible=v;}
    void SetPosition(glm::vec3 pos){this->position=pos;}
    short GetScore(){return this->score;}
    glm::vec3 GetSize(){return this->size;}
    bool IsWall(){return this->is_wall;}
//    Model GetModel(){return this->GetModel();}
    
private:
    
    float gravity = 0.002f;
//    bool onSurface = false;
    
    glm::vec3 position;
    glm::vec3 size;
    glm::mat4 translation;
    
    short score = 0;
    bool visible = true;
    bool is_wall;
};
