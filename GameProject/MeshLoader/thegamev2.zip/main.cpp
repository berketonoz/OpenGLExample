// Std. Includes
#include <string>
#include <cstdlib>

// GLEW
#define GLEW_STATIC
#include <GL/glew.h>

// GLFW
#include <GLFW/glfw3.h>

// GL includes
#include "Shader.h"
#include "Camera.h"
#include "Model.h"
#include "GameObject.h"
#include "Player.h"
#include "Object.h"

// GLM Mathemtics
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Other Libs
#include "SOIL2/SOIL2.h"
#include <GLUT/GLUT.h>



#define GLFW_KEY_SPACE 32
#define CARROT_AMOUNT 5
#define OBSTACLE_AMOUNT 5


// Properties
const GLuint WIDTH = 800, HEIGHT = 600;
int SCREEN_WIDTH, SCREEN_HEIGHT;

// Function prototypes
void KeyCallback( GLFWwindow *window, int key, int scancode, int action, int mode );
void MouseCallback( GLFWwindow *window, double xPos, double yPos );
void DoMovement(Player &player);
void DoLightStuff(const Shader &shader, Player player);

//GLfloat x = 0.0f, y = 0.0f, z = 30.0f;
GLfloat x = 0.0f, y = 10.0f, z = 40.0f;

// Camera
Camera camera( glm::vec3( x, y, z ) );

//glm::vec3 lightPos( 1.2f, 1.0f, 2.0f );


bool keys[1024];
GLfloat lastX = 400, lastY = 300;
bool firstMouse = true;

GLfloat deltaTime = 0.0f;
GLfloat lastFrame = 0.0f;

int main( )
{
    // Init GLFW
    glfwInit( );
    // Set all the required options for GLFW
    glfwWindowHint( GLFW_CONTEXT_VERSION_MAJOR, 3 );
    glfwWindowHint( GLFW_CONTEXT_VERSION_MINOR, 3 );
    glfwWindowHint( GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE );
    glfwWindowHint( GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE );
    glfwWindowHint( GLFW_RESIZABLE, GL_FALSE );
    
    // Create a GLFWwindow object that we can use for GLFW's functions
    GLFWwindow *window = glfwCreateWindow( WIDTH, HEIGHT, "LearnOpenGL", nullptr, nullptr );
    
    if ( nullptr == window )
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate( );
        
        return EXIT_FAILURE;
    }
    
    glfwMakeContextCurrent( window );
    
    glfwGetFramebufferSize( window, &SCREEN_WIDTH, &SCREEN_HEIGHT );
    
    // Set the required callback functions
    glfwSetKeyCallback( window, KeyCallback );
    glfwSetCursorPosCallback( window, MouseCallback );
    
    // GLFW Options
    glfwSetInputMode( window, GLFW_CURSOR, GLFW_CURSOR_DISABLED );
    
    // Set this to true so GLEW knows to use a modern approach to retrieving function pointers and extensions
    glewExperimental = GL_TRUE;
    // Initialize GLEW to setup the OpenGL Function pointers
    if ( GLEW_OK != glewInit( ) )
    {
        std::cout << "Failed to initialize GLEW" << std::endl;
        return EXIT_FAILURE;
    }
    
    // Define the viewport dimensions
    glViewport( 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT );
    
    // OpenGL options
    glEnable( GL_DEPTH_TEST );
    
    // Setup and compile our shaders
    Shader shader( "resources/shaders/modelLoading.vs", "resources/shaders/modelLoading.frag" );
  
    
    std::vector<vector<float> > object_positions;
       for(int i = 0; i < CARROT_AMOUNT+OBSTACLE_AMOUNT; i++){
           float rx = -3 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX/6)), ry = -0.25, rz = -20 + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX/50));
           vector<float> pos;
           pos.push_back(rx);
           pos.push_back(ry);
           pos.push_back(rz);
           object_positions.push_back(pos);
       }
    
    // Load models
    //Model ourModel( "resources/models/model1/nanosuit.obj" );
    Model ourModel("resources/models/model3/Grass_Block.obj");
    Model carrotModel("resources/models/model2/Carrot.obj");
    Model crateModel("resources/models/model5/woodencrate.obj");
    Model obstacleModel("resources/models/model2/Poplar_Tree.obj");
    //Model carrot3v2("resources/models/model4/10170_Carrot_v01_L3.obj");
    
    
    //-----------------------------------------------------------------------
    Object *obj1 = new Object(ourModel, glm::vec3( 3.1f, 0.1f, 80.f ));
    
    Player *player = new Player(crateModel, glm::vec3(0.1f, 0.1f, 0.1f));
    vector<Object> objects;
    
    for(int i = 0; i < CARROT_AMOUNT; i++){
        Object carrot(carrotModel, glm::vec3( 0.5f, 0.5f, 0.5f ),false);
        objects.push_back(carrot);
    }
    for(int i = 0; i < OBSTACLE_AMOUNT; i++){
        Object obs(obstacleModel, glm::vec3( 0.5f, 0.5f, 0.5f ));
        objects.push_back(obs);
    }
    
    //-----------------------------------------------------------------------

    
    
    shader.use();
    glUniform1i( glGetUniformLocation( shader.Program, "material.diffuse" ), 0 );
    glUniform1i( glGetUniformLocation( shader.Program, "material.specular" ), 1 );
    
//    obstacles[0].Draw(shader, glm::vec3(0.0f,2.0f,0.0f));
    player->Draw(shader,glm::vec3(0.0f,5.0f,75.0f));
 
    glm::mat4 projection = glm::perspective( camera.GetZoom( ), ( float )SCREEN_WIDTH/( float )SCREEN_HEIGHT, 0.1f, 50.0f );
    
    
    
    // Game loop
    while(!glfwWindowShouldClose(window)){
//         Set frame time
        GLfloat currentFrame = glfwGetTime( );
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
//        cout << "DeltaTime=" << deltaTime << endl;
        // Check and call events
        glfwPollEvents();
        DoMovement(*player);
        
        // Clear the colorbuffer
        glClearColor( 0.1f, 0.1f, 0.1f, 1.0f );
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        //-----------------------------------------------------------
        
        shader.use( );
        
        glm::vec3 lightPos(0.0f,0.0f,0.0f);
        DoLightStuff(shader,*player);

        glm::mat4 view = camera.GetViewMatrix( );
        glUniformMatrix4fv( glGetUniformLocation( shader.Program, "projection" ), 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv( glGetUniformLocation( shader.Program, "view" ), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv( glGetUniformLocation( shader.Program, "model" ), 1, GL_FALSE, glm::value_ptr(obj1->GetTranslation()));

        // Draw the surface
        obj1->Draw(shader,glm::vec3( 0.0f, -0.5f, 0.0f ));
        
//        glm::vec3 cam_pos = camera.GetPosition();
        glm::vec3 obj_pos = player->GetPosition();

        glUniformMatrix4fv( glGetUniformLocation( shader.Program, "model" ), 1, GL_FALSE, glm::value_ptr(player->GetTranslation()));
        //Draw the crate
        player->Draw(shader,obj_pos);
        
//        obstacles[0].Draw(shader, glm::vec3(0.0f,0.0f,10.0f));
//        cout << objects.size() << endl;
        
        // Draw the loaded carrots
        for(int i = 0; i < CARROT_AMOUNT+OBSTACLE_AMOUNT; i++){
            glUniformMatrix4fv( glGetUniformLocation( shader.Program, "model" ), 1, GL_FALSE, glm::value_ptr(objects[i].GetTranslation()));
            objects[i].Draw(shader, glm::vec3(object_positions[i][0], object_positions[i][1], object_positions[i][2]));
        }

        player->Collect(objects);
        player->RunPhysics(*obj1,deltaTime);
//        player->Move();
        camera.FollowObject(*player);
        glfwSwapBuffers(window);
    }
    glfwTerminate( );
    return 0;
}

// Moves/alters the camera positions based on user input
void DoMovement(Player &player)
{
    float pos_x = camera.GetPosition().x;
    // Camera controls
    if ( keys[GLFW_KEY_W] || keys[GLFW_KEY_UP] )
    {
//        camera.ProcessKeyboard( FORWARD, deltaTime );
        player.Move(GO_FORWARD,deltaTime);
    }
    
    if ( keys[GLFW_KEY_S] || keys[GLFW_KEY_DOWN] )
    {
        player.Move(GO_BACKWARD,deltaTime);
    }
    
    if ( (keys[GLFW_KEY_A] || keys[GLFW_KEY_LEFT]) && player.GetPosition().x >= -3)
    {
//        camera.ProcessKeyboard( LEFT, deltaTime );
        player.Move(GO_LEFT, deltaTime);
    }
    
    if ( (keys[GLFW_KEY_D] || keys[GLFW_KEY_RIGHT]) && player.GetPosition().x <= 3)
    {
//        camera.ProcessKeyboard( RIGHT, deltaTime );
        player.Move(GO_RIGHT, deltaTime);
    }
    
    if(keys[GLFW_KEY_SPACE]){
//        camera.ProcessKeyboard(UP, deltaTime);
        player.Move(GO_UP, deltaTime);
    }
}

// Is called whenever a key is pressed/released via GLFW
void KeyCallback( GLFWwindow *window, int key, int scancode, int action, int mode )
{
    if ( GLFW_KEY_ESCAPE == key && GLFW_PRESS == action )
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
    
    if ( key >= 0 && key < 1024 )
    {
        if ( action == GLFW_PRESS )
        {
            keys[key] = true;
        }
        else if ( action == GLFW_RELEASE )
        {
            keys[key] = false;
        }
    }
}

void MouseCallback( GLFWwindow *window, double xPos, double yPos )
{
    if ( firstMouse )
    {
        lastX = xPos;
        lastY = yPos;
        firstMouse = false;
    }
    
    GLfloat xOffset = xPos - lastX;
    GLfloat yOffset = lastY - yPos;  // Reversed since y-coordinates go from bottom to left
    
    lastX = xPos;
    lastY = yPos;
    
    camera.ProcessMouseMovement( xOffset, yOffset );
}

void DoLightStuff(const Shader &shader, Player player){
    GLint lightPosLoc = glGetUniformLocation( shader.Program, "light.position" );
    GLint lightSpotdirLoc = glGetUniformLocation( shader.Program, "light.direction" );
    GLint lightSpotCutOffLoc = glGetUniformLocation( shader.Program, "light.cutOff" );
    GLint lightSpotOuterCutOffLoc = glGetUniformLocation( shader.Program, "light.outerCutOff" );
    GLint viewPosLoc = glGetUniformLocation( shader.Program, "viewPos" );
//    glUniform3f( lightPosLoc, player->GetPosition( ).x, player->GetPosition( ).y, player->GetPosition( ).z);
    glUniform3f( lightPosLoc, player.GetPosition().x, player.GetPosition().y + 2, player.GetPosition().z);
    glUniform3f( lightSpotdirLoc, 0.0f, 0.0f, -2.0f);
    glUniform1f( lightSpotCutOffLoc, glm::cos( glm::radians( 2.5f ) ) );
    glUniform1f( lightSpotOuterCutOffLoc, glm::cos( glm::radians( 15.0f ) ) );
//    glUniform3f( viewPosLoc, player->GetPosition( ).x, player->GetPosition( ).y, player->GetPosition( ).z);
    glUniform3f( viewPosLoc, player.GetPosition().x, player.GetPosition().y, player.GetPosition().z);
        // Set lights properties
    glUniform3f( glGetUniformLocation( shader.Program, "light.ambient" ),   0.5f, 0.5f, 0.5f );
        // We set the diffuse intensity a bit higher; note that the right lighting conditions differ with each lighting method and environment.
        // Each environment and lighting type requires some tweaking of these variables to get the best out of your environment.
        
    glUniform3f( glGetUniformLocation( shader.Program, "light.diffuse" ), 5.0f, 5.0f, 5.0f );
    glUniform3f( glGetUniformLocation( shader.Program, "light.specular" ), 5.0f, 5.0f, 5.0f );
    glUniform1f( glGetUniformLocation( shader.Program, "light.constant" ), 1.0f );
    glUniform1f( glGetUniformLocation( shader.Program, "light.linear" ), 0.09 );
    glUniform1f( glGetUniformLocation( shader.Program, "light.quadratic" ), 0.0042 ); //0.032
        // Set material properties
    glUniform1f( glGetUniformLocation( shader.Program, "material.shininess" ), 2.0f );
}
