#pragma once
#include "Mesh.h"
#include "Model.h"
#include "GameObject.h"
#include "Intersect.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


class AABB{
    
public:
    AABB(const glm::vec3 &min, const glm::vec3 & max): m_min(min), m_max(max){}
    
    void intersect(const AABB &aabb) const{
        glm::vec3 distance1 = aabb.GetMin() - m_max;
        glm::vec3 distance2 = m_min - aabb.GetMax();
        glm::vec3 distances = glm::max(distance1, distance2);
        
        //return Intersect()
    }
    /*
    float GetMaxComp(glm::vec3 v){
        float max = 0.0;
        for(int i = 0; i < v.length(); i++){
            
        }
        return max;
    }*/
    
    inline const glm::vec3 & GetMin() const {return this->m_min;}
    inline const glm::vec3 & GetMax() const {return this->m_max;}
    


private:
    const glm::vec3 m_min;
    const glm::vec3 m_max;
    
};
