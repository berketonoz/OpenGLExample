#pragma once
#include "Mesh.h"
#include "Model.h"
#include "GameObject.h"
#include "Object.h"
//#include "AABB.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


enum LRU{
    GO_LEFT,
    GO_RIGHT,
    GO_UP,
    GO_BACKWARD,
    GO_FORWARD
};

class Player : public GameObject{
    
public:
    Player(const Model &m, glm::vec3 s):GameObject(m,s), size(s){}
    
    glm::vec3 GetPosition() const{return this->position;}
    
    void Collect(vector<Object> &objects){
        for(int i = 0; i < objects.size(); i++){
//            cout << objects[i].IsWall() << endl;
            std::vector<float> mins = this->GetModel().GetMins();
            std::vector<float> maxs = this->GetModel().GetMaxs();
            std::vector<float> minsObj = objects[i].GetModel().GetMins();
            std::vector<float> maxsObj = objects[i].GetModel().GetMaxs();
            glm::vec3 pos = this->GetPosition();
            glm::vec3 obj_pos = objects[i].GetPosition();
            bool stat = CheckCollision(mins,maxs,minsObj,maxsObj,pos,obj_pos,objects[i].GetSize());
            if(stat){
                if(objects[i].IsWall() == false){
//                    std::cout << "Collided " << i << std::endl;
                    objects[i].SetVisible(false);
                    score += 1;
                }
                else{
                    this->position.z += 0.04;
                }
            }
        }
    }

    bool CheckCollision(const std::vector<float> mins, std::vector<float> maxs, std::vector<float> minsObj, std::vector<float> maxsObj, glm::vec3 pos, glm::vec3 obj_pos, glm::vec3 size) const {
        
        //we need to scale the bounding boxes to our size
        return ((mins[0]*this->size[0]+pos.x <= maxsObj[0]*size.x+obj_pos.x && maxs[0]*this->size[0]+pos.x  >= minsObj[0]*size.x+obj_pos.x)&&
                (mins[1]*this->size[1]+pos.y <= maxsObj[1]*size.y+obj_pos.y && maxs[1]*this->size[1]+pos.y  >= minsObj[1]*size.y+obj_pos.y)&&
                (mins[2]*this->size[2]+pos.z <= maxsObj[2]*size.z+obj_pos.z && maxs[2]*this->size[2]+pos.z  >= minsObj[2]*size.z+obj_pos.z));
    }
    
    void Draw(Shader shader, glm::vec3 position) {
        if(this->visible == true){
            this->position = position;
            translation = glm::mat4(1.0f);
            translation = glm::translate( translation, position); // Translate to position
            translation = glm::scale(translation, size);    //Size of the object
            glUniformMatrix4fv( glGetUniformLocation( shader.Program, "model" ), 1, GL_FALSE,glm::value_ptr(translation)  );
            this->GetModel().Draw(shader);
        }
    }
    
    void RunPhysics(Object surface, float deltatime){
//        if(!onSurface){
            this->position.y -= this->gravity;
            this->gravity += 0.05*deltatime;
            std::vector<float> mins = surface.GetModel().GetMins();
            std::vector<float> maxs = surface.GetModel().GetMaxs();
            std::vector<float> minsObj = surface.GetModel().GetMins();
            std::vector<float> maxsObj = surface.GetModel().GetMaxs();
            glm::vec3 pos = this->GetPosition();
            glm::vec3 obj_pos = surface.GetPosition();
            
            //To adjust the surface maximum
//            maxsObj[1] += 5.0f;
        
            bool stat = CheckCollision(mins, maxs, minsObj, maxsObj, pos, obj_pos,surface.GetSize());

            if(stat){
//                onSurface = true;
                this->gravity -= this->gravity;
            }
        }
//    }
    
    void Move(){
        this->position.z -= 0.04;
    }
    
    void Move(LRU lr, GLfloat deltaTime){
//        GLfloat velocity = this->movementSpeed * deltaTime;
        if(lr == GO_LEFT){
            this->position.x -= this->velocity*deltaTime;
        }
        if(lr == GO_RIGHT){
            this->position.x += this->velocity*deltaTime;
        }
        if(lr == GO_UP){
            this->position.y += 0.02f;
        }
        if(lr == GO_BACKWARD){
            this->position.z += this->velocity*deltaTime;
        }
        if(lr == GO_FORWARD){
            this->position.z -= this->velocity*deltaTime;
        }
    }
    
    
    glm::mat4 GetTranslation() const{return this->translation;}
    void SetVisible(bool v) {this->visible=v;}
    void SetPosition(glm::vec3 pos){this->position=pos;}
    short GetScore(){return this->score;}
    
private:
    
    float velocity = 10.0f;
    float gravity = 0.002f;
//    bool onSurface = false;
    
    glm::vec3 position;
    glm::vec3 size;
    glm::mat4 translation;
    
    short score = 0;
    bool visible = true;
};
